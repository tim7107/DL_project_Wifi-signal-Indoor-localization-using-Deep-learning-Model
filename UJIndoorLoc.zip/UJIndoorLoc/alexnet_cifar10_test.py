"""
Created on Sun Jun 16 10:23:47 2019

@author: user
"""
import time
from skimage.transform import rescale, resize, downscale_local_mean
import numpy as np
from keras.datasets import mnist
from keras.datasets import cifar100
from keras.datasets import cifar10
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense, Activation, Conv2D, MaxPooling2D, Flatten,Dropout, Conv1D, MaxPooling1D
from keras.optimizers import Adam
from keras import optimizers,regularizers
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ReduceLROnPlateau
from sklearn.utils import shuffle
import keras.callbacks
from keras.backend import clear_session
from sklearn.model_selection import train_test_split
from keras.layers import BatchNormalization
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
starttime = time.time()
timenow = time.localtime(time.time())
TSTART = "V" + str(timenow[1]).zfill(2) + str(timenow[2]).zfill(2) + "_" + str(timenow[3]).zfill(2) + str(timenow[4]).zfill(2)
save_path = "./report/"
Save_path = "/home/user/Desktop/DATA1/u105011242/alexnet/model/"
#%%
clear_session()
#%% import mnist dataset
lr = 0.0001#0.00022
epoch = 120
batch_size = 32
class_num = 10
weight_decay = 0.0005
iterations = 782
#load mnist data set
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

x_train = x_train.reshape(-1,32,32,3).astype('float32')
x_test = x_test.reshape(-1,32,32,3).astype('float32')
x_train,x_valid,y_train,y_valid  = train_test_split(x_train, y_train, test_size = 0.4)

#normalize to 0-1
x_train = x_train/255
x_test = x_test/255
x_valid = x_valid/255
#one-hot encoding 
y_train = np_utils.to_categorical(y_train, class_num)
y_test = np_utils.to_categorical(y_test, class_num)
y_valid = np_utils.to_categorical(y_valid, class_num)
#%% Build AlexNet model
def Alexnet(class_num):
    #Test original alexnet
    model = Sequential()
    #First Convolution and Pooling layer
    model.add(Conv2D(96,(11,11),strides=(1,1),input_shape=(32,32,3),padding='valid',activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))     
    #Second Convolution and Pooling layer
    model.add(Conv2D(256,(5,5),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))  
    #Three Convolution layer and Pooling Layer
    model.add(Conv2D(384,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
    model.add(Conv2D(384,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
    model.add(Conv2D(256,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))   
    #Fully connection layer
    model.add(Flatten())
    model.add(Dense(4096,activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(4096,activation='relu'))
    model.add(Dropout(0.5))
    #Classfication layer
    model.add(Dense(class_num,activation='softmax'))
#    model = Sequential()
#    #First Convolution and Pooling layer
#    model.add(Conv2D(120,(11,11),strides=(1,1),input_shape=(32,32,3),padding='valid',activation='relu', kernel_initializer='uniform'))
#    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))     
#    #Second Convolution and Pooling layer
#    model.add(Conv2D(150,(5,5),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
#    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))  
#    #Three Convolution layer and Pooling Layer
#    model.add(Conv2D(180,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
#    model.add(Conv2D(20,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
#    model.add(Conv2D(80,(3,3),strides=(1,1),padding='same',activation='relu', kernel_initializer='uniform'))
#    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))   
#    #Fully connection layer
#    model.add(Flatten())
#    model.add(Dense(630,activation='relu'))
#    model.add(Dropout(0.5))
#    model.add(Dense(660,activation='relu'))
#    model.add(Dropout(0.5))
#    #Classfication layer
#    model.add(Dense(class_num,activation='softmax'))
    #    model = Sequential()
    #Test original alexnet
#    model.add(Conv2D(150,(3,3),strides=(1,1),input_shape=(32,32,3),padding='same',kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))
#        
#    model.add(Conv2D(260,(5,5),strides=(1,1),padding='same',kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(MaxPooling2D(pool_size=(2,2)))
#    
#    model.add(Conv2D(170,(3,3),strides=(1,1),padding='same',kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(Dropout(0.4))    
#    model.add(Conv2D(210,(3,3),strides=(1,1),padding='same',kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(Dropout(0.4))    
#    model.add(Conv2D(180,(3,3),strides=(1,1),padding='same',kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(MaxPooling2D(pool_size=(3,3),strides=(2,2)))   
#    
#    model.add(Flatten())
#    model.add(Dense(410,kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(Dense(1280,kernel_regularizer=regularizers.l2(weight_decay)))
#    model.add(BatchNormalization())
#    model.add(Activation('relu'))
#    model.add(Dense(class_num,activation='softmax'))
    return model
print('Bulid model...')
model = Alexnet(class_num)
model.summary() #print out model information
model.compile(optimizer=Adam(lr=lr, beta_1=0.9, beta_2=0.999, epsilon=1e-08),
              loss = 'categorical_crossentropy',metrics=['accuracy'])
#%% data generator

datagen = ImageDataGenerator(              #1
        featurewise_center=False,  
        samplewise_center=False,  
        featurewise_std_normalization=False,  
        samplewise_std_normalization=False,  
        zca_whitening=False,  
        rotation_range=0, 
        width_shift_range=0.1, 
        height_shift_range=0.1, 
        horizontal_flip=True, 
        vertical_flip=False)

datagen.fit(x_train) 
#%% training 
print('Training...')
early_stopping = keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, verbose=5) 

History = model.fit_generator(datagen.flow(x_train, y_train,batch_size=batch_size),
                              steps_per_epoch=iterations,
                              epochs=epoch,
                              callbacks = [early_stopping],
                              validation_data=(x_valid, y_valid))
model.save(Save_path+'cifar10_model.h5')
test_acc = model.evaluate(x_test, y_test)[1]
endtime = time.time()
Parameter=model.count_params()
compresstion_rate = (21622154- Parameter)/21622154*100.0
total_time = int(endtime - starttime)
starttime = str(int(starttime)).zfill(2)
endtime =  str(int(endtime)).zfill(2)
d = int(total_time/86400)
h = int((total_time-d*86400)/3600)
m = int((total_time-d*86400-h*3600)/60)
s =int(total_time-d*86400-h* 3600-m*60)
with open(save_path+"report"+TSTART+".txt", 'a') as fh: 
    fh.write("****************************************************\n")
    fh.write("*                                                  *\n")
    fh.write("*                Final result                      *\n")
    fh.write("*                                                  *\n")
    fh.write("****************************************************\n")
    fh.write("start time = "+ starttime+'\n')
    fh.write("stop  time = "+ endtime+'\n')
    fh.write("Time consuming = "+str(d)+" day "+str(h)+" hours "+str(m)+" minute "+str(s)+"second"+"\n")
    train_acc = round(History.history['acc'][-1]*100, 2)
    valid_acc = round(History.history['val_acc'][-1]*100, 2)
    fh.write("Compression rate="+str(compresstion_rate)+"\n")
    fh.write("train acc = "+str(train_acc)+"\n")
    fh.write("valid_acc = "+str(valid_acc)+"\n")
    fh.write("test_acc = "+str(test_acc)+"\n")
    # Pass the file handle in as a lambda function to make it callable
    fh.write('\n')
    model.summary(print_fn=lambda x: fh.write(x + '\n'))
